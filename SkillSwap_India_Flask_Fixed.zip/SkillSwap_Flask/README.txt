SKILLSWAP INDIA - FLASK VERSION

1. Open a terminal in this folder.
2. Install dependencies:
   pip install -r requirements.txt
3. Start the app:
   python app.py
4. Open:
   http://127.0.0.1:5000

No Supabase is used.
The backend uses Flask + SQLite. The database file skillswap.db is created automatically.

The main fixes include:
- Create Profile uses /api/signup.
- Sign In uses the correct Flask /api/signin endpoint.
- Successful signup/signin stores the backend user in the browser session state.
- Existing Flask session is restored through /api/me after refresh.
- Passwords are hashed by Flask/Werkzeug.
